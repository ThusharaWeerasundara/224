//lab 6 part 1

iverilog -o test cpu_testbench.v
vvp test
gtkwave e16388_cpu_wavedata.vcd

True Submision: This was recorded as a late submision because after the deadline there was a update therefore we resubmitted this again.

Due date 	Tuesday, 2 June 2020, 11:59 PM
Time remaining 	Assignment was submitted 20 hours 47 mins late
Last modified 	Wednesday, 3 June 2020, 8:46 PM

