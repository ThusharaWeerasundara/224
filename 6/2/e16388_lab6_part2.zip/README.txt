//lab 6 part 2

iverilog -o test cpu_testbench.v
vvp test
gtkwave e16388_cpu_wavedata.vcd


simulation screen shots are in as
GTKWave01 - e16388_cpu_wavedata.vcd
GTKWave02 - e16388_cpu_wavedata.vcd
GTKWave03 - e16388_cpu_wavedata.vcd
GTKWave04 - e16388_cpu_wavedata.vcd
GTKWave05 - e16388_cpu_wavedata.vcd
GTKWave06 - e16388_cpu_wavedata.vcd

Due date 	Wednesday, 17 June 2020, 11:59 PM
Time remaining 	Assignment was submitted 5 days 3 hours early
Last modified 	Friday, 12 June 2020, 8:33 PM
As in Submision date png file
Resubmitted after debuging some unexpected results in ALU

