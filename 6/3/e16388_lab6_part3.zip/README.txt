//lab 6 part 3

iverilog -o test cpu_testbench.v
vvp test
gtkwave e16388_cpu_wavedata.vcd


simulation screen shots are in as
GTKWave01 - e16388_cpu_wavedata.vcd 
GTKWave02 - e16388_cpu_wavedata.vcd 
GTKWave03 - e16388_cpu_wavedata.vcd 
GTKWave04 - e16388_cpu_wavedata.vcd 
GTKWave05 - e16388_cpu_wavedata.vcd 
